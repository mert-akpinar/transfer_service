<?php
$ADMIN_EMAIL = 'admin@example.com';
$ADMIN_PASSWORD = 'admin123';

// Google Maps API key
$GOOGLE_API_KEY = 'AIzaSyDK6XuGHSJ3k_evTqYJ7PWSrLSrKI0yAiU'; 